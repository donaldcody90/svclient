<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['authtoken']= 'AFcWxV21C7fd0v3bYYYRCpSSRl31A1me59j7dCK9l-wts-zoWRmi5QyF';
$config['posturl']= 'https://www.sandbox.paypal.com/cgi-bin/webscr';
$config['business']= 'adminvultr@gmail.com';
$config['returnurl']= 'http://localhost/server/svclient/billing/ipn';
$config['notifyurl']= 'http://localhost/server/svclient/billing/ipn';

?>
