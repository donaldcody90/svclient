<?php 
function index()
{
	redirect('auth');
}
?>