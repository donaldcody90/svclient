			<div class="footer">
				<p>Recent News - Apr 25, 2016 - <a href="#">view all</a></p>
				<p class="footer-2">Add Flexibility And Resiliency To Your Cloud With Reserved IPs!</p>
			</div>
			
        </div>

    </body>
</html>